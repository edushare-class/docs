-- EduShare Supabase setup
-- Run this entire script in Supabase Dashboard > SQL Editor.
-- It creates a private Storage bucket, a documents table, RLS policies, and a download counter function.

create extension if not exists pgcrypto;

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 180),
  grade text not null check (grade in ('Lớp 10','Lớp 11','Lớp 12','Đại học / Cao đẳng','Khác')),
  subject text not null check (char_length(subject) between 1 and 80),
  lesson text not null check (char_length(lesson) between 1 and 180),
  description text not null default '' check (char_length(description) <= 1500),
  author_name text not null default 'Thành viên',
  original_name text not null check (char_length(original_name) between 1 and 255),
  mime_type text not null default 'application/octet-stream',
  file_size bigint not null check (file_size > 0 and file_size <= 20971520),
  storage_path text not null unique,
  downloads bigint not null default 0 check (downloads >= 0),
  created_at timestamptz not null default now(),
  constraint documents_storage_path_owner check (storage_path like owner_id::text || '/%')
);

alter table public.documents enable row level security;

drop policy if exists "Authenticated users can read documents" on public.documents;
create policy "Authenticated users can read documents"
on public.documents for select to authenticated using (true);

drop policy if exists "Authenticated users can add their own documents" on public.documents;
create policy "Authenticated users can add their own documents"
on public.documents for insert to authenticated
with check (auth.uid() = owner_id and storage_path like auth.uid()::text || '/%');

-- Only the owner can delete their metadata. This starter app does not expose a delete button.
drop policy if exists "Owners can delete their own documents" on public.documents;
create policy "Owners can delete their own documents"
on public.documents for delete to authenticated using (auth.uid() = owner_id);

-- Do not grant general UPDATE rights for download counts; use a narrowly scoped RPC.
create or replace function public.increment_document_downloads(document_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  -- Only authenticated sessions can call this function. It updates only the counter,
  -- without granting general UPDATE permission on the documents table.
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  update public.documents
  set downloads = downloads + 1
  where id = document_id;
end;
$$;

revoke all on function public.increment_document_downloads(uuid) from public;
grant execute on function public.increment_document_downloads(uuid) to authenticated;

-- Private bucket: files are not accessible through public URLs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'class-documents',
  'class-documents',
  false,
  20971520,
  array[
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain',
    'image/png',
    'image/jpeg',
    'image/webp',
    'application/octet-stream'
  ]
)
on conflict (id) do update set
  public = false,
  file_size_limit = 20971520,
  allowed_mime_types = excluded.allowed_mime_types;

-- Authenticated users can read/download files in the private bucket.
drop policy if exists "Authenticated users can read class files" on storage.objects;
create policy "Authenticated users can read class files"
on storage.objects for select to authenticated
using (bucket_id = 'class-documents');

-- Each user can upload only into a folder named with their own auth UID.
drop policy if exists "Users can upload to their own folder" on storage.objects;
create policy "Users can upload to their own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'class-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Users can remove files only from their own folder (used for cleanup after a failed metadata insert).
drop policy if exists "Users can delete files in their own folder" on storage.objects;
create policy "Users can delete files in their own folder"
on storage.objects for delete to authenticated
using (
  bucket_id = 'class-documents'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Important: don't add a service_role key to browser code. The publishable/anon key is intended for clients;
-- RLS policies above are what protect data. Never disable RLS for this project.
