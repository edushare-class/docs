# EduShare — bản dùng Supabase

Bản này thay `localStorage` bằng Supabase Auth, Postgres và private Storage. Chưa hoạt động cho đến khi em tự điền cấu hình dự án Supabase.

## Có gì trong gói?
- `index.html`: giao diện EduShare, đăng nhập/đăng ký bằng email và Google, danh sách tài liệu yêu cầu đăng nhập, upload file gốc, tải xuống có kiểm tra kích thước, xem trước PDF/ảnh/DOCX/TXT.
- `supabase_setup.sql`: bảng, RLS, bucket riêng tư và chính sách quyền truy cập.
- `README.md`: hướng dẫn thiết lập.

## A. Tạo backend Supabase
1. Tạo project tại https://supabase.com/ và giữ thông tin đăng nhập dự án an toàn.
2. Mở **SQL Editor** trong Dashboard, tạo query mới, dán toàn bộ `supabase_setup.sql`, rồi Run.
3. Mở **Project Settings → API** (tên menu có thể thay đổi). Sao chép **Project URL** và **publishable key** (hoặc anon/public key cũ).
4. Mở `index.html`, tìm:
   - `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
   - `PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE`
   rồi thay bằng giá trị thật. Không dán `service_role` / secret key vào HTML, GitHub, hoặc trình duyệt.
5. Trong **Authentication → URL Configuration**, đặt **Site URL** thành URL website thực tế. Thêm URL triển khai vào **Redirect URLs**, ví dụ `https://TEN-TAI-KHOAN.github.io/TEN-REPO/`. Nếu chạy local, dùng một máy chủ phát triển và thêm đúng URL local được dùng.

## B. Bật đăng nhập email
1. Trong **Authentication → Sign In / Providers** (tên có thể hơi khác), bật Email.
2. Nên giữ email confirmation bật nếu đây là kho dùng chung. Người đăng ký sẽ cần bấm liên kết trong email trước khi đăng nhập.
3. Kiểm tra phần Email/SMTP theo hướng dẫn hiện tại của Supabase nếu muốn gửi email xác nhận ổn định cho nhiều bạn trong lớp.

## C. Bật Google OAuth
1. Tạo OAuth Client trong Google Cloud Console, cấu hình OAuth consent screen.
2. Trong Supabase, mở Authentication → Providers → Google và bật Google.
3. Lấy **Callback URL** do chính trang Supabase hiển thị trong cấu hình Google provider. Thêm URL đó vào **Authorized redirect URIs** của Google OAuth client.
4. Dán Google Client ID và Client Secret vào Supabase provider settings, lưu lại.
5. Trong Google Cloud, thêm domain website vào **Authorized JavaScript origins** nếu Google yêu cầu.
6. Trong Supabase URL Configuration, thêm URL website vào Redirect URLs. Kiểm tra callback/redirect theo đúng URL Supabase cung cấp; không tự đoán callback URL.
7. Kiểm tra cả luồng đăng nhập Google trên URL triển khai HTTPS. Google OAuth có thể không hoạt động nếu domain/redirect URI không khớp chính xác.

## D. Triển khai trên GitHub Pages
1. Tạo repository GitHub, tải `index.html` lên thư mục gốc repo.
2. Vào **Settings → Pages**, chọn nguồn triển khai theo nhánh/repo của em rồi lưu.
3. Đợi GitHub Pages xuất bản website, mở URL HTTPS được cấp.
4. Thêm chính xác URL đó vào Supabase Authentication Redirect URLs và kiểm tra đăng nhập email + Google.
5. Nếu sửa code, commit/push lại lên GitHub.

## E. Kiểm thử trước khi gửi link cho lớp
- Đăng ký bằng email mới → xác nhận email (nếu bật) → đăng nhập sai mật khẩu phải bị từ chối.
- Tải lại trang → phiên vẫn còn nếu chưa đăng xuất.
- Đăng nhập ở trình duyệt khác → thấy cùng danh sách tài liệu.
- Upload PDF/Word/ảnh, ghi lại dung lượng gốc → tải xuống và so sánh dung lượng/mở file.
- Đăng xuất → danh sách tài liệu biến mất; cố truy cập Storage/Database khi chưa đăng nhập phải bị từ chối.
- Thử upload file quá 20 MB và định dạng không hỗ trợ: phải báo lỗi, không báo thành công.
- Kiểm tra Google OAuth cả trên domain Pages thật.
- Nếu bất kỳ thao tác nào thất bại, mở Developer Tools → Console/Network để xem lỗi, nhưng không chia sẻ token, mật khẩu hay client secret.

## Bảo mật và giới hạn quan trọng
- Tài liệu chỉ cho người dùng đã xác thực truy cập; bucket là **private** và bảng bật RLS.
- `publishable`/`anon` key trong frontend là bình thường khi RLS được cấu hình đúng. **Tuyệt đối không** đặt `service_role`/secret key trong HTML.
- Chính sách hiện cho mọi tài khoản đã đăng nhập xem và tải file; upload vào thư mục UID của chính họ. Xóa metadata chỉ chủ sở hữu mới được phép, nhưng bản giao diện này chưa có chức năng xóa.
- Vì yêu cầu “chỉ thành viên lớp”, đăng nhập email tự nó không chứng minh một người thuộc lớp. Nếu cần giới hạn thành viên, nên thêm allowlist email/domain hoặc quy trình mời thành viên và policy tương ứng trước khi công khai.
- Không nên cho phép upload tùy tiện nếu website được chia sẻ rộng: cần quản trị viên, báo cáo nội dung, hạn mức, kiểm tra file và chính sách xóa.
- Supabase có giới hạn dung lượng/băng thông theo gói. Kiểm tra trang Billing/Usage của dự án trước khi cả lớp dùng nhiều.
- Xem trước DOCX là chuyển đổi phía trình duyệt, không giữ nguyên tuyệt đối mọi định dạng. PPT/PPTX/XLS/XLSX hiện có thể tải xuống nhưng chưa có trình xem trước tích hợp.
- Mã HTML dùng CDN cho thư viện. Nếu mạng trường chặn CDN, cần đóng gói thư viện hoặc dùng bundler.
